<div class="d-flex flex-column-reverse question-list">
    <?php for($i = 1; $i < ((config('question.max') / 5) + 1); $i++): ?>
        <?php for($j = ($i - 1)*5 + 1; $j <= $i*5; $j++): ?>
            <div class="d-flex align-items-center question-item <?php echo $j == $question['number'] ? 'active' : null; ?>" id="question-<?php echo $j; ?>">
                <span><i class="fa fa-file-code-o" aria-hidden="true"></i> Câu <?php echo $j; ?></span>
            </div>
        <?php endfor; ?>
        <div class="d-flex align-items-center question-group" id="group_question_<?php echo $i; ?>">
            <span><i class="fa fa-folder-open" aria-hidden="true"></i> <?php echo config('question.level_label.' . $i); ?></span>
        </div>
    <?php endfor; ?>
</div>
