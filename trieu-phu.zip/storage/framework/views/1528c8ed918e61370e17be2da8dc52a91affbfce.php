<div class="info-container">
    <div class="info">
        <span>
            Mưa trôi cả bầu trời nắng, trượt theo những nỗi buồn
            Thấm ướt lệ sầu môi đắng vì đánh mất hy vọng
            Lần đầu gặp nhau dưới mưa, trái tim rộn ràng bởi ánh nhìn
            Tình cảm dầm mưa thấm lâu, em nào ngờ

            Mình hợp nhau đến như vậy thế nhưng không phải là yêu!
            Và em muốn hỏi anh rằng "chúng ta là thế nào?"
            Rồi lặng người đến vô tận, trách sao được sự tàn nhẫn
            Anh trót vô tình thương em như là em gái
        </span>
    </div>
    <div class="d-flex justify-content-center">
        <div class="start-button">
            <a href="<?php echo route('questions.index'); ?>"><span>Tôi đã sẵn sàng >></span></a>
        </div>
    </div>
</div>
