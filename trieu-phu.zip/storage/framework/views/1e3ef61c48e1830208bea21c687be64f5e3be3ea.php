<!DOCTYPE html>
<html lang="<?php echo app()->getLocale(); ?>">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>The Final Countdown - jQuery.countdown</title>
    <link rel="stylesheet" href="<?php echo mix('/css/app.css'); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>

<body>
    <?php echo $__env->make('includes.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-2 col-md-3 question-list-container">
                <?php echo $__env->make('includes.question-list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="col-lg-10 col-md-9 content-container" style="background-image: url(images/bg2.jpg)">
                <div class="content" >
                    <?php echo $__env->make('includes.countdown', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    
                    <?php echo $__env->make('includes.question', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    
                </div>
            </div>
        </div>
    </div>
    <div class="d-flex flex-row-reverse align-items-center footer">
        <span>Framgia © 2018</span>
    </div>
    <div class="result" id="result">
        <div class="result-body">
            <span id="result-content">Chính xác</span>
        </div>
    </div>
    <canvas id="firework"></canvas>
    <script type="text/javascript">
        var canContinue = <?php echo $canContinue; ?>;
        var timeOut = '<?php echo isset($timeOut) ? $timeOut : ''; ?>';
        var answerUrl = '<?php echo route('questions.checkAnswer'); ?>';
        var homeUrl = '<?php echo route('home'); ?>';
        var nextQuestionUrl = '<?php echo route('questions.nextQuestion'); ?>';
        var maxQuestion = <?php echo config('question.max'); ?>;
        var questionNumber = '<?php echo $question['number']; ?>';
    </script>
    <script type="text/javascript" src="<?php echo mix('/js/app.js'); ?>"></script>
</body>

</html>
