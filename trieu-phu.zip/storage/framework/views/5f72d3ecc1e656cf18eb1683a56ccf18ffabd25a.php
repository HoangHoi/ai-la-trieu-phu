<div class="card question-item ck-editor__view">
    <div class="card-header">
        Câu <?php echo $question->id; ?>

        (<?php echo $question->level; ?>)
        [<a href="<?php echo route('admin.questions.delete', ['question' => $question->id]); ?>">delete</a>]
    </div>
    <div class="card-body">
        <div class="question-content">
            <?php echo $question->content; ?>

        </div>
        <div class="question-answer">
            <div class="question-answer-item <?php echo $question->correct_answer == 'a' ? 'question-answer-correct' : ''; ?>">A. <?php echo $question->a; ?></div>
            <div class="question-answer-item <?php echo $question->correct_answer == 'b' ? 'question-answer-correct' : ''; ?>">B. <?php echo $question->b; ?></div>
            <div class="question-answer-item <?php echo $question->correct_answer == 'c' ? 'question-answer-correct' : ''; ?>">C. <?php echo $question->c; ?></div>
            <div class="question-answer-item <?php echo $question->correct_answer == 'd' ? 'question-answer-correct' : ''; ?>">D. <?php echo $question->d; ?></div>
        </div>
    </div>
</div>
