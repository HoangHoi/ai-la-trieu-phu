<div class="time-over d-flex justify-content-center" id="time-over">
    <span style="color: #fff; font-size: 80px; font-weight: 900;">Hết giờ</span>
</div>

{{-- <h1 class="timeout"><span>H</span><span>O</span><span>V</span><span>E</span><span>R</span><span> </span><span>O</span><span>V</span><span>E</span><span>R</span><span> </span><span>M</span><span>E</span><span>!</span></h1> --}}
