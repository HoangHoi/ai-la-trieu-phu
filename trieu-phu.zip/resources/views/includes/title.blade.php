<div class="d-flex justify-content-center title-name">
    <span>Triệu phú IT</span>
</div>
