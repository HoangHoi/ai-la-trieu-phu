<div class="info-container">
    <div class="info">
        <span>
            Nhiều khi anh mong được một lần nói ra hết tất cả thay vì,
            Ngồi lặng im nghe em kể về anh ta bằng đôi mắt lấp lánh
            Đôi lúc em tránh ánh mắt của anh
            Vì dường như lúc nào em cũng hiểu thấu lòng anh.
            Ko thể ngắt lời, càng ko thể để giọt lệ nào đc rơi
        </span>
    </div>
    <div class="d-flex justify-content-center">
        <div class="start-button" data-toggle="modal" data-target="#modal-register">
            <span>Đăng kí ngay!</span>
        </div>
    </div>
</div>
