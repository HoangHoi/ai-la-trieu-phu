import Adapter from './adapter';

export default class ImageUploadAdapter extends Adapter {
    constructor(loader) {
        super(loader, '/admin-13H10O1994I11235813/upload/image', 'image');
    }
}
