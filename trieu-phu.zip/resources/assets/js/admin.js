require('./editor2.js');
editor('#content');
