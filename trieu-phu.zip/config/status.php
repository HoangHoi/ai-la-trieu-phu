<?php

return [
    'time_out' => 'time_out',
    'no_test' => 'no_test',
];
