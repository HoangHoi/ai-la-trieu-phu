<?php

return [
    'time_out' => 15,
];
