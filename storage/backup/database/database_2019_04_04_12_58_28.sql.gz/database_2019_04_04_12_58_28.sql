-- MySQL dump 10.13  Distrib 5.7.25, for Linux (x86_64)
--
-- Host: localhost    Database: trieuphu
-- ------------------------------------------------------
-- Server version	5.7.25-0ubuntu0.18.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (3,'2018_04_02_090603_create_database',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `a` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `b` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `c` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `d` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correct_answer` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` tinyint(3) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES (1,'<p><strong>Cho n là 1 số nguyên lẻ, đáp án nào sau đây cũng là số nguyên lẻ?</strong></p>','n – 1','n + 1','2n','4n + 1','d',1,'2018-04-12 23:33:08','2018-04-12 23:33:08'),(2,'<p><strong>Doanh thu từ công ty được chia cho Ben, Bill và Bob lần lượt theo tỉ lệ: 1:2:3. Hỏi nếu phần lợi nhuận Bill nhận được là $300, thì khoản Bob nhận được là bao nhiêu?</strong></p>','$150','$450','$600','$900','b',1,'2018-04-12 23:33:31','2018-04-12 23:33:31'),(3,'<p><strong>Cho hình tam giác có chiều cao là 4cm, nằm trong 1 hình vuông có cạnh là 5cm. Hỏi phần diện tích còn lại của hình vuông (phần bị bôi đậm) là bao nhiêu?</strong></p><figure class=\"image\"><img src=\"/storage/images/5ad04f4fcb852.png\"></figure>','5','10','15','20','c',1,'2018-04-12 23:34:05','2018-04-12 23:34:05'),(4,'<p><strong>Khoảng nào sau đây thể hiện đúng nhất các giá trị lớn hơn -3 và nhỏ hơn 6?</strong></p>','{x : -3 > x > 6}','{x: -3 ≥ x ≥ 6}','{x: -3 < x < 6}','{x: -3 ≤ x ≤ 6}','c',1,'2018-04-12 23:34:30','2018-04-12 23:34:30'),(5,'<figure class=\"image\"><img src=\"/storage/images/5ad04f89851fb.png\"></figure><p>Cho tam giác ABC kéo dọc theo đường thẳng x tạo thành tam giác AB’C’ và tam giác AB’’C’’.</p><p>Biết AC=AC’=AC’’. Tìm tỉ lệ 3 tam giác trên?</p>','1 : 1 : 1','1 : 1 : 2','1 : 2 : 2','1 : 2 : 3','d',1,'2018-04-12 23:35:18','2018-04-12 23:35:18'),(6,'<p><strong>1 người đàn ông mua 1 chiếc áo hết $120 trong đợt giảm giá và tiết kiệm được $30 so với giá cũ. Hỏi chiếc áo được giảm bao nhiêu %?</strong></p>','20','25','100/3','80','a',1,'2018-04-12 23:35:37','2018-04-12 23:35:37'),(7,'<p><strong>Cho a và b là 2 số nguyên, đáp án nào sau đây có khả năng không phải là số nguyên?</strong></p>','2a - 5b','a^7','b^a','ab','c',1,'2018-04-12 23:36:01','2018-04-12 23:36:01'),(8,'<p><strong>Cho dãy số A = {a, b, c, d, e}, hỏi A có tất ca bao nhiêu tập con?</strong></p>','2','5','10','32','d',1,'2018-04-12 23:36:20','2018-04-12 23:36:20'),(9,'<p><strong>Số nào sau đây không phải là số nguyên tố?</strong></p>','11','21','31','41','b',1,'2018-04-12 23:36:36','2018-04-12 23:36:36'),(10,'<p><strong>2p^2- 15p + 25 =</strong></p>','(p - 5)(2p - 5)','(p - 5)(2p + 5)','(p + 5)(2p - 5)','(2p - 15)(p + 5)','a',1,'2018-04-12 23:37:01','2018-04-12 23:37:01'),(11,'<p><strong>Tính PF</strong></p><figure class=\"image\"><img src=\"/storage/images/5ad0506692dd4.png\"></figure>','10m','20m','42m','90m','b',1,'2018-04-12 23:38:50','2018-04-12 23:38:50'),(12,'<p><strong>Đâu là số tiền lãi đơn nhận được khi đầu tư $10 000 trong 3 tháng với tỉ lệ 5% mỗi năm?</strong></p>','$100','$125','$500','$1500','b',1,'2018-04-13 00:17:17','2018-04-13 00:17:17'),(13,'<p><strong>Chu vi của một hình chữ nhật là 26 cm. Hình chữ nhật được chuyển thành hình vuông bằng cách gấp ba lần chiều rộng và một phần tư chiều dài. Chu vi của hình vuông là?</strong></p>','9 cm','12 cm','20 cm','26 cm','b',1,'2018-04-13 00:17:45','2018-04-13 00:17:45'),(14,'<p><strong>cho sơ đồ dưới đây, thống kê thời gian của 35 sinh viên giải quyết một vấn đề.</strong></p><figure class=\"image\"><img src=\"/storage/images/5ad059c79bbb1.png\"></figure><p><strong>Tính xác suất chọn ngẫu nhiên 1 học sinh để giải 1 bài toán trong 3 phút?</strong></p>','3/35','4/35','3/7','4/7','b',1,'2018-04-13 00:18:52','2018-04-13 00:18:52'),(17,'<p><strong>Đáp án nào sau đây không phải là độ dài của các cạnh 1 hình tam giác vuông?</strong></p>','3, 4, 5','5, 12, 13','8, 15, 17','12, 15, 18','d',1,'2018-04-13 00:20:10','2018-04-13 00:20:10'),(19,'<p>Cho 3x + y = 19 , và x + 3y = 1. Tính giá trị biểu thức 2x+2y:</p>','20','18','11','10','d',1,'2018-04-13 00:21:51','2018-04-13 00:21:51'),(20,'<p>Cho x và y là 2 số nguyên. Biết x + y &lt; 11 , and x &gt; 6. Giá trị nhỏ nhất của biểu thức x – y là:</p>','1','2','4','-2','c',1,'2018-04-13 01:08:12','2018-04-13 01:08:12'),(21,'<p><strong>Andy giải các câu từ 74 đến 125 trong sách bài tập toán. Hỏi Andy phải giải tất cả bao nhiêu câu?</strong></p>','53','52','51','50','b',1,'2018-04-13 01:09:12','2018-04-13 01:09:12'),(22,'<p><strong>Giả sử x và y là 2 số nguyên. Biết &nbsp;3x + 2y = 13. Giá trị y có thể là?</strong></p>','0','1','2','3','c',1,'2018-04-13 01:09:52','2018-04-13 01:09:52'),(23,'<p><strong>Cho hình tam giác ABC, có AD = DB, DE song song với BC, và diện tích tam giác ABC bằng 40. Hỏi diện tích tam giác AED là bao nhiêu?</strong></p><figure class=\"image\"><img src=\"/storage/images/5ad065dfe5065.png\"></figure>','10','15','20','30','a',1,'2018-04-13 01:10:32','2018-04-13 01:10:32'),(24,'<p><strong>Giả sử n &gt; 0, đáp án nào sau đây là đáp án đúng?</strong></p><p>I. n^2 &gt; 0</p><p>II. n – n^2 &lt;0</p><p>III. 2n – 2 &gt;0</p>','I','II','III','Không đáp án nào đúng','a',1,'2018-04-13 01:11:51','2018-04-13 01:11:51'),(25,'<p><strong>6 người bạn gặp nhau trong 1 buổi tiêc. Lần lượt từng đôi một bắt tay nhau. Hỏi có tất cả bao nhiêu cái bắt tay?</strong></p>','30','21','18','15','d',1,'2018-04-13 01:12:10','2018-04-13 01:12:10'),(26,'<p><strong>Nếu x^2 – y^2 = 55, và x – y = 11. Hỏi y = ?</strong></p>','8','3','-8','-3','d',1,'2018-04-13 01:12:52','2018-04-13 01:12:52'),(27,'<p><strong>1 hỗn hợp 19 lít gồm 1 lít nước cam và 18 lít nước thường. Nếu thêm x lít nước cam và y lít nước thường được thêm vào hỗn hợp đến khi đủ 54 lít sao cho tỉ lệ nước cam và nước thường là ½ . Hỏi giá trị của x phải là?</strong></p>','17','18','27','35','a',2,'2018-04-13 01:13:30','2018-04-13 01:13:30'),(29,'<p><strong>Cho a và b là 2 số nguyên dương, coi a*b là ab +1 Nếu x và y là 2 số nguyên dương và x*y = 16. Đáp án nào sau đây là giá trị của y?</strong></p><p>I. 1</p><p>II. 2</p><p>III. 3</p>','I','II','I và III','III','c',2,'2018-04-13 01:15:49','2018-04-13 01:15:49'),(30,'<p><strong>1 người được trả lương $3/h trong 40 giờ làm việc. Lương được nhân đôi nếu làm tăng ca. Hỏi nếu người này được trả $168, thì anh ấy &nbsp;phải làm tăng ca trong bao nhiêu giờ?</strong></p>','8','16','28','48','a',2,'2018-04-13 01:16:13','2018-04-13 01:16:13'),(31,'<p><strong>1 hình trụ và 1 hình nón có đáy và chiều cao như nhau, biết thể tích hình trụ là V cm3. Tính thể tích hình nón?</strong></p>','1/4 V','1/3 V','1/2 V','V','b',1,'2018-04-13 01:17:33','2018-04-13 01:17:33'),(32,'<p><strong>Trung bình của 1 dãy số giảm từ 14 xuống 11 khi bỏ số 35 ra khỏi dãy số. Hỏi ban đầu dãy số đó có tất cả bao nhiêu số?</strong></p>','8','11','21','25','a',2,'2018-04-13 01:17:57','2018-04-13 01:17:57'),(33,'<p><strong>Một nhà thầu hoàn thành 5/9 của một công việc trước khi một nhà thầu thứ hai hoàn thành thêm 1/3. Hỏi công việc còn lại bao nhiêu?</strong></p>','1/9','4/9','2/3','8/9','a',2,'2018-04-13 01:18:28','2018-04-13 01:18:28'),(34,'<p><strong>Cặp bất đẳng thức nào sau đây mô tả vùng tô đậm trên đồ thị?</strong></p><figure class=\"image\"><img src=\"/storage/images/5ad067ee629f5.png\"></figure>','2x – 3y ≤ 3 and x + y ≤ 4','2x – 3y ≤ 3 and x + y ≥ 4','2x – 3y ≥ 3 and x + y ≥ 4','2x – 3y ≥ 3 and x + y ≤ 4','c',2,'2018-04-13 01:19:16','2018-04-13 01:19:16'),(35,'<p><strong>Cho m và p là 2 số nguyên dương, (m + p) m là 1 số chẵn. Khẳng định nào sau đây là đúng?</strong></p>','Nếu m là số lẻ, thì p là số lẻ','Nếu m là số lẻ, thì p là số chẵn','Nếu m là số chẵn, thì p là số chẵn','Nếu m là số chẵn, thì p là số lẻ','a',2,'2018-04-13 01:19:55','2018-04-13 01:19:55'),(36,'<p><strong>Cho 2 hình tròn đường kính bằng nhau bị cắt bởi 1 hình chữ nhật có kích thức 16 x 8. Biết đường tròn có đường kính lớn nhất có thể, hỏi diện tích phần còn thừa của hình chữ nhật (phần không bị bôi đậm) là bao nhiêu?</strong></p><figure class=\"image\"><img src=\"/storage/images/5ad06840c342b.png\"></figure>','104.32','78.65','54.24','27.52','d',2,'2018-04-13 01:20:34','2018-04-13 01:20:34'),(37,'<p>Cho biểu thức: x = y – (50/y), biết x, y&gt;0. Nếu tăng gấp đôi giá trị y trong biểu thức trên, thì giá trị x sẽ:</p>','Giảm','Tăng gấp 4 lần','Tăng nhiều hơn 2 lần','Không thay đổi','c',2,'2018-04-13 01:21:38','2018-04-13 01:21:38'),(38,'<p><strong>Cho ASB bằng ¼ hình tròn, PQRS là hình chữ nhật biết PQ = 8, và PS = 6. Chiều dài của cung AQB là ?</strong></p><figure class=\"image\"><img src=\"/storage/images/5ad068a3d5728.png\"></figure>','5π','10π','25','1','a',2,'2018-04-13 01:22:15','2018-04-13 01:22:15'),(39,'<p><strong>Kim giờ chạy từ giữa trưa đến 2h30 chiều cùng ngày quay được 1 góc bao nhiêu độ ?</strong></p>','720','180','75','65','c',2,'2018-04-13 01:23:02','2018-04-13 01:23:02'),(40,'<p><strong>Jeff mất 20 phút để chạy hết đường đua trong lần đầu tiên, và mất 25 phút cho lần chạy thứ 2. Hỏi tốc độ trung bình trong 1 giờ cho cả 2 lần chạy là bao nhiêu nếu đường đua dài 3 dặm?</strong></p>','6','8','10','12','b',2,'2018-04-13 01:23:35','2018-04-13 01:23:35'),(41,'<p><strong>Cho bánh xe A có đường kính x, bánh xe B có đường kính y. Bánh xe đầu tiên lăn 100 vòng thì hết đoạn đường d. Hỏi bánh xe B phải lăn bao nhiêu vòng mới hết đoạn đường d?</strong></p>','100xy','100x / y','100y – x','100x – y','b',2,'2018-04-13 01:24:12','2018-04-13 01:24:12'),(42,'<p><strong>Giá của 1 chiếc xe đạp đã giảm 25%, giá mới của nó tiếp tục giảm hơn 20% so với giá trước. Để giá của 2 lần giảm này bằng 1 lần giảm duy nhất, thì % lần giảm này phải là?</strong></p>','45%','40%','35%','32.5%','b',2,'2018-04-13 01:24:58','2018-04-13 01:24:58'),(43,'<p><strong>Nếu (x^5)(y^4)(z^2) &lt; 0. Đáp án nào sau đây là đáp án đúng?</strong></p><p>I. xy &lt;0</p><p>II. yz &lt;0</p><p>III. xz &lt;0</p>','I','II','III','Không đáp án nào đúng','d',2,'2018-04-13 01:25:45','2018-04-13 01:25:45'),(44,'<p><strong>Ở 1 làng nọ, mỗi hộ gia đình cần m lít nước để sinh hoạt mỗi tháng. Hỏi với tỷ lệ này, nếu làng có n hộ gia đình, thì với p lít nước sẽ sinh hoạt được trong bao lâu (tính theo tháng)</strong></p>','np / m','mn / p','p / mn','npm','c',2,'2018-04-13 01:26:55','2018-04-13 01:26:55'),(45,'<p><strong>Tìm số hàng đơn vị của 2^320</strong></p>','0','2','4','6','d',2,'2018-04-13 01:27:22','2018-04-13 01:27:22'),(46,'<p><strong>(3 x 10^4) + (2 x 10^2) + (4 x 10) =</strong></p>','302400','32400','30240','3240','c',2,'2018-04-13 01:27:42','2018-04-13 01:27:42'),(47,'<p><strong>Đáp án nào sau đây mô tả chính xác nhất mối quan hệ giữa A và B được thể hiện trong bên dưới?</strong></p><figure class=\"image\"><img src=\"/storage/images/5ad06a2fb4a88.png\"></figure>','B = A + 4','B = 2A + 1','B = 3A – 1','B = A² + 1','d',2,'2018-04-13 01:28:38','2018-04-13 01:28:38'),(48,'<p><strong>Trong 1 câu lạc bộ thể thao có 30 thành viên, trong đó có 17 người chơi cầu lông, 19 người chơi tennis, và 2 người không chơi môn thể thao nào nói trên. Hỏi có bao nhiêu thành viên chơi cả 2 bộ môn thể thao trên?</strong></p>','7','8','9','10','b',2,'2018-04-13 01:28:55','2018-04-13 01:28:55'),(49,'<p><strong>Hình chữ nhật ABCD có chu vi bằng 26, và nửa đường tròn đường kính AD có diện tích bằng 8π. Hỏi chu vi phần hình không bị bôi đậm trong hình là bao nhiêu?</strong></p><figure class=\"image\"><img src=\"/storage/images/5ad06a763a4c6.png\"></figure>','26 + 4π','18 + 8π','18 + 4π','14 + 4π','c',3,'2018-04-13 01:29:44','2018-04-13 01:29:44'),(50,'<p><strong>Cho hình vuông a nội tiếp đường tròn đường kính d, tính tổng diện tích &nbsp;phần hình bị bôi đậm trong hình theo d.</strong></p><figure class=\"image\"><img src=\"/storage/images/5ad06a9466f99.png\"></figure>','d^2(π/4 - 1/2)','d^2(π/4 - 1/4)','d^2(π/2 - 1/2)','d^2(π - 2)','a',3,'2018-04-13 01:31:42','2018-04-13 01:31:42'),(51,'<p><strong>Cho A và B đối xứng với nhau qua điểm I. Hỏi có thể vẽ được tất cả bao nhiêu đường tròn sao cho trọng tâm của nó nằm trên đường thẳng I và 2 điểm A, B đều nằm trên đường tròn đó ?</strong></p><figure class=\"image\"><img src=\"/storage/images/5ad06b016c028.png\"></figure>','1','2','3','>10','d',3,'2018-04-13 01:32:18','2018-04-13 01:32:18'),(52,'<p><strong>Cho 3 điểm BCD tạo thành 1 đường thẳng, biết góc BAC = ¼ &nbsp;góc ACB. Tính diện tích tam giác ACD?</strong></p><figure class=\"image\"><img src=\"/storage/images/5ad06b244bdaa.png\"></figure>','140','120','60','Không đủ thông tin','d',3,'2018-04-13 01:33:05','2018-04-13 01:33:05'),(53,'<p><strong>Cho hình dưới đây, hệ số góc l là?</strong></p><figure class=\"image\"><img src=\"/storage/images/5ad06b591b112.png\"></figure>','-3','-1/3','0','1/3','b',3,'2018-04-13 01:34:02','2018-04-13 01:34:02'),(54,'<p>2 đàn anh khóa trên là Abby và Ben, và 2 đàn em khóa dưới là Cathy và Dave, được giao cho 3 tủ đựng đồ cá nhân với luật như sau:</p><p>Họ được giao cho cả 3 tủ</p><p>Abby và Ben không dùng chung tủ với nhau</p><p>Đàn anh không dùng chung tủ với đàn em</p><p>Đôi nào trong số các cặp sau dùng chung tủ với nhau?</p><p>I. <strong>Abby và Ben</strong></p><p>II. <strong>Ben và Cathy</strong></p><p>III. <strong>Cathy và Dave</strong></p>','I','II','I và II','III','d',3,'2018-04-13 01:35:50','2018-04-13 01:35:50'),(55,'<p>Ai tạo ra ngôn ngữ lập trình C?</p>','Ken Thompson','Dennis Ritchie','Robin Milner','Frieder Nake','b',2,'2019-04-04 05:10:38','2019-04-04 05:10:38'),(56,'<p>Đâu là ngôn ngữ lập trình bậc cao đầu tiên?</p>','C','COBOL','FORTRAN','C++','c',2,'2019-04-04 05:13:53','2019-04-04 05:13:53'),(57,'<p>Đâu là ứng dụng xử lý văn bản đầu tiên?</p>','MS Word','Apple i Work','Sun StartOffice','WordStar','d',3,'2019-04-04 05:14:22','2019-04-04 05:14:22'),(58,'<p>Ai phát triển ngôn ngữ lập trình Java?</p>','James Gosling','Douglas Engelbart','Edmund M. Clarke','James D. Foley','a',2,'2019-04-04 05:14:59','2019-04-04 05:14:59'),(59,'<p>Đâu là bộ nhớ điện động trên hệ thống máy tính?</p>','Ổ cứng','RAM','ROM','Ổ đĩa quang','b',2,'2019-04-04 05:15:27','2019-04-04 05:15:27'),(60,'<p>Một terabyte (1TB) tương đương với?</p>','1028 GB','2012 GB','1000 GB','1024 GB','d',1,'2019-04-04 05:15:55','2019-04-04 05:15:55'),(61,'<p>Đâu là hệ điều hành do Apple Inc phát triển và sử dụng?</p>','Windows','Android','iOS','UNIX','c',1,'2019-04-04 05:16:31','2019-04-04 05:16:31'),(62,'<p>Linus Torvalds phát triển hệ điều hành nào?</p>','Windows','Mac OS','UNIX','Linux','d',1,'2019-04-04 05:17:07','2019-04-04 05:17:07'),(63,'<p>Trong các hàm sau, hàm nào được dùng để in một chuỗi kí tự không định dạng ra màn hình?</p>','puts()','printf()','scanf()','gets()','a',2,'2019-04-04 05:18:09','2019-04-04 05:18:09'),(64,'<p>Kết quả của chương trình sau:</p><figure class=\"image\"><img src=\"/storage/images/5ca5f76fec152.png\"></figure>','8','10','12','Kết quả khác','c',2,'2019-04-04 05:24:56','2019-04-04 05:24:56'),(65,'<p>Sử dụng cách truyền nào trong hàm sẽ không làm thay đổi giá trị của biến trong chương trình chính?</p>','Truyền bằng giá trị','Truyền bằng tham số','Cả A và B đều đúng','Cả A và B đều sai','a',2,'2019-04-04 05:26:48','2019-04-04 05:26:48'),(66,'<p>Cho biết giá trị của biểu thức 5&gt;1</p>','-1','0','1','Không câu nào đúng','b',2,'2019-04-04 05:27:40','2019-04-04 05:27:40'),(67,'<p>Cho biết giá trị của biểu thức 2+4&gt;2&amp;&amp;4&lt;2</p>','0','1','-1','Không câu nào đúng','a',2,'2019-04-04 05:28:07','2019-04-04 05:28:07'),(68,'<p>Biến con trỏ có thể chứa</p>','Địa chỉ vùng nhớ của một biến khác','Giá trị của một biến khác','Cả A và B đều đúng','Cả A và B đều sai','a',2,'2019-04-04 05:28:43','2019-04-04 05:28:43'),(69,'<p>Dữ liệu kí tự bao gồm</p>','Các kí tự số chữ số','Các kí tự chữ cái','Các kí tự đặc biệt','Tất cả đáp án trên','d',1,'2019-04-04 05:30:11','2019-04-04 05:30:11'),(70,'<p>Nếu hàm được gọi trước khi nó định nghĩa thì điều kiện là gì?</p>','Kiểu trả về của hàm phải là kiểu void','Kiểu đầu vào của hàm phải là kiểu void','Trước khi gọi hàm nó phải được khai báo','Hàm chỉ trả về kiểu dữ liệu boolean','c',2,'2019-04-04 05:30:56','2019-04-04 05:30:56'),(71,'<p>Kiểu dữ liệu float có thể xử lí dữ liệu trong phạm vi nào?</p>','3.4*10-38 đến 3.4*1038','-32768 đến 32767','-128 đến 127','0 đến 65535','a',2,'2019-04-04 05:31:40','2019-04-04 05:31:40'),(72,'<p>Giả sử có câu lệnh ch=’A’. Vậy ch sẽ chứa bao nhiêu byte</p>','1','2','3','4','a',2,'2019-04-04 05:32:18','2019-04-04 05:32:18'),(73,'<p>Giả sử có câu lệnh ch[]= \"A\". ch chứa bao nhiêu bytes</p>','1','2','3','4','b',2,'2019-04-04 05:32:37','2019-04-04 05:32:37'),(74,'<p>Kết quả in ra màn hình của chương trình sau:</p><figure class=\"image\"><img src=\"/storage/images/5ca5f9c3f3756.png\"></figure>','A','a','65','Kết quả khác','c',2,'2019-04-04 05:34:43','2019-04-04 05:34:43'),(75,'<p>Kết quả của chương trình sau:</p><figure class=\"image\"><img src=\"/storage/images/5ca5fa31e0731.png\"></figure>','B','b','98','Kết quả khác','b',2,'2019-04-04 05:36:25','2019-04-04 05:36:25'),(76,'<p>Kết quả in ra màn hình của chương trình sau:</p><figure class=\"image\"><img src=\"/storage/images/5ca5fa8211954.png\"></figure>','6','5','1','0','d',3,'2019-04-04 05:37:46','2019-04-04 05:37:46'),(77,'<p>Kết quả in ra màn hình của chương trinh sau là gì:</p><figure class=\"image\"><img src=\"/storage/images/5ca5fad528f76.png\"></figure>','\" 1 2 3 4 \"','\" 2 3 \"','\" 2 \"','Chương trình không chạy được','c',3,'2019-04-04 05:39:51','2019-04-04 05:39:51'),(78,'<p>Trong bài test của bạn có một số câu hỏi. Bạn đã trả lời sai 10 câu hỏi. Kết quả thang điểm của bạn chỉ đạt 60%. Vậy bài test của bạn có tất cả bao nhiêu câu hỏi?</p>','20','25','30','35','b',2,'2019-04-04 05:40:21','2019-04-04 05:40:21'),(79,'<p>Trong 4 loại sau đây, loại nào có đặc tính ít giống với 3 loại còn lại?</p>','Tỏi','Nho','Rau diếp cá','Nấm','b',1,'2019-04-04 05:40:46','2019-04-04 05:40:46'),(80,'<p>Trời âm u, đất tù mù, có 3 người gù, chung một cây dù. Hỏi người nào ướt?</p>','Người thứ nhất','Người thứ hai','Người thứ ba','Không có người nào ướt','d',1,'2019-04-04 05:41:10','2019-04-04 05:41:10'),(81,'<p>Bạn có 84 quả táo đựng trong 12 giỏ, nếu muốn ăn 1/3 số táo trong mỗi giỏ thì bạn cần ít nhất bao nhiêu lần cắn, biết rằng mỗi lần bạn cắn được 1/3 của 1/2 quả táo.</p>','168','121','144','225','a',2,'2019-04-04 05:41:34','2019-04-04 05:41:34'),(82,'<p>Tám người sơn được 3 cái nhà trong 6 giờ. Hỏi với 12 người sẽ sơn được bao nhiêu cái nhà trong 12 giờ?</p>','3 cái','5 cái','7 cái','9 cái','d',2,'2019-04-04 05:42:07','2019-04-04 05:42:07'),(83,'<p>Người ta đổ nước vào một bể cạn theo tỷ lệ không đổi, sau 8 giờ thì đổ được 3/5 thể tích của bể. Hỏi cần thêm thời gian là bao lâu nữa để đổ đầy bể nước đó?</p>','5 giờ 30 phút','5 giờ 20 phút','4 giờ 48 phút','3 giờ 12 phút','b',2,'2019-04-04 05:44:01','2019-04-04 05:44:01'),(84,'<p>Sắp xếp các chữ cái \"HÙCYẬNUC\" bạn được tên</p>','Một tỉnh thành','Một nhà thơ','Một bài hát','Một vị vua','b',1,'2019-04-04 05:44:31','2019-04-04 05:44:31');
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_question`
--

DROP TABLE IF EXISTS `user_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_question` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `question_id` int(10) unsigned NOT NULL,
  `answer` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_number` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_question`
--

LOCK TABLES `user_question` WRITE;
/*!40000 ALTER TABLE `user_question` DISABLE KEYS */;
INSERT INTO `user_question` VALUES (1,1,11,'c',1,'2019-04-03 04:03:58','2019-04-03 04:03:58'),(2,2,5,'a',1,'2019-04-03 04:04:52','2019-04-03 04:04:52'),(3,3,24,'a',1,'2019-04-03 04:05:36','2019-04-03 04:05:36'),(4,3,7,'d',2,'2019-04-03 04:05:40','2019-04-03 04:05:40'),(5,4,31,'b',1,'2019-04-03 04:46:58','2019-04-03 04:46:58'),(6,4,25,'d',2,'2019-04-03 04:47:08','2019-04-03 04:47:08'),(7,4,26,'d',3,'2019-04-03 04:47:31','2019-04-03 04:47:31'),(8,4,7,'c',4,'2019-04-03 04:47:59','2019-04-03 04:47:59'),(9,4,17,'d',5,'2019-04-03 04:48:14','2019-04-03 04:48:14'),(10,4,39,'c',6,'2019-04-03 04:48:55','2019-04-03 04:48:55'),(11,4,41,'b',7,'2019-04-03 04:49:20','2019-04-03 04:49:20'),(12,4,47,'d',8,'2019-04-03 04:49:34','2019-04-03 04:49:34'),(13,4,46,'c',9,'2019-04-03 04:49:51','2019-04-03 04:49:51'),(14,4,48,'b',10,'2019-04-03 04:50:26','2019-04-03 04:50:26'),(15,4,53,'b',11,'2019-04-03 04:50:39','2019-04-03 04:50:39'),(16,4,50,'b',12,'2019-04-03 04:52:11','2019-04-03 04:52:11'),(17,5,7,'c',1,'2019-04-03 04:59:40','2019-04-03 04:59:40'),(18,5,6,'a',2,'2019-04-03 05:00:01','2019-04-03 05:00:01'),(19,5,9,'b',3,'2019-04-03 05:00:07','2019-04-03 05:00:07'),(20,5,31,'b',4,'2019-04-03 05:00:12','2019-04-03 05:00:12'),(21,5,26,'d',5,'2019-04-03 05:00:23','2019-04-03 05:00:23'),(22,5,32,'a',6,'2019-04-03 05:01:33','2019-04-03 05:01:33'),(23,5,36,'b',7,'2019-04-03 05:02:33','2019-04-03 05:02:33'),(24,6,12,'b',1,'2019-04-03 05:03:57','2019-04-03 05:03:57'),(25,6,17,'d',2,'2019-04-03 05:04:08','2019-04-03 05:04:08'),(26,6,25,'d',3,'2019-04-03 05:04:16','2019-04-03 05:04:16'),(27,6,5,'d',4,'2019-04-03 05:04:46','2019-04-03 05:04:46'),(28,6,2,'b',5,'2019-04-03 05:05:03','2019-04-03 05:05:03'),(29,6,29,'c',6,'2019-04-03 05:05:40','2019-04-03 05:05:40'),(30,6,34,'b',7,'2019-04-03 05:06:34','2019-04-03 05:06:34'),(31,7,5,'d',1,'2019-04-03 05:07:19','2019-04-03 05:07:19'),(32,7,11,'b',2,'2019-04-03 05:07:37','2019-04-03 05:07:37'),(33,7,19,'d',3,'2019-04-03 05:07:46','2019-04-03 05:07:46'),(34,7,14,'b',4,'2019-04-03 05:08:30','2019-04-03 05:08:30'),(35,7,7,'c',5,'2019-04-03 05:08:35','2019-04-03 05:08:35'),(36,7,43,'d',6,'2019-04-03 05:09:10','2019-04-03 05:09:10'),(37,7,27,'a',7,'2019-04-03 05:09:40','2019-04-03 05:09:40'),(38,7,34,'c',8,'2019-04-03 05:10:32','2019-04-03 05:10:32'),(39,7,35,'a',9,'2019-04-03 05:11:17','2019-04-03 05:11:17'),(40,7,38,'a',10,'2019-04-03 05:11:52','2019-04-03 05:11:52'),(41,7,51,'d',11,'2019-04-03 05:12:17','2019-04-03 05:12:17'),(42,7,52,'d',12,'2019-04-03 05:12:46','2019-04-03 05:12:46'),(43,7,53,'b',13,'2019-04-03 05:12:58','2019-04-03 05:12:58'),(44,7,54,'d',14,'2019-04-03 05:13:34','2019-04-03 05:13:34'),(45,7,49,'b',15,'2019-04-03 05:14:31','2019-04-03 05:14:31'),(46,9,31,'b',1,'2019-04-04 04:58:08','2019-04-04 04:58:08'),(47,9,22,'d',2,'2019-04-04 04:58:16','2019-04-04 04:58:16'),(48,10,24,'c',1,'2019-04-04 05:03:01','2019-04-04 05:03:01'),(49,11,5,'b',1,'2019-04-04 05:07:36','2019-04-04 05:07:36'),(50,12,1,'d',1,'2019-04-04 05:07:56','2019-04-04 05:07:56'),(51,12,20,'b',2,'2019-04-04 05:08:00','2019-04-04 05:08:00');
/*!40000 ALTER TABLE `user_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birth_year` int(10) unsigned NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'hoang Huu Hoi','hoi@gmail.com','BK','09823272823',19983,'7BowMvLpQMnBTAl6lTYXss0E1kOk1rqhRHH3T10YCfsXHNXedqK7kouubcPQ','2019-04-03 04:03:51','2019-04-03 04:03:51'),(2,'ádad','fj@ad.aa','ádasd','46345634',12313,'boD2Sgd4tjIln2luWgKgaBFFtCk6bIcqydN4JPscfBJxWnbZaGHR5IP27Spz','2019-04-03 04:04:46','2019-04-03 04:04:46'),(3,'ádasdsa','q3weq3w@uyi.tyiu','ưerter','567657856',23423,'yFQcIEXXmWkJNooduxTtiwuAy9lO66hkZ4BUH0YUU6PKzd7NJ4OWSEWtqnXw','2019-04-03 04:05:13','2019-04-03 04:05:13'),(4,'HHH','deobiet@mgail.com','ABC','012345678',2000,'G0oBQSi2OdKHj2Rwpv6SuK3Wzr9q2YcHHpYlLBn5qAaGrokJOLgO36g5AV9v','2019-04-03 04:46:41','2019-04-03 04:46:41'),(5,'HHH','hanh@gmail.com','ftu','01238765',2000,'eKBUlag59NfPQuK6spFl6kcuPLoEAwKgsVmApXysnNWYJB8mdAUfIm0HVFcY','2019-04-03 04:59:32','2019-04-03 04:59:32'),(6,'hhh','hhh@gmail.com','neu','0123456789',2000,'z8vJJcDAtvFNBOL4vSRAy82NPLjCZRX1uKnVPqtlcZx1J4kFEXejtgqhmvV8','2019-04-03 05:03:22','2019-04-03 05:03:22'),(7,'hfdkjhgf','hou@esdf.dfs','ádad','3482381',21231,'SIpvEKMi28U5jtH9f1jD5zvURMTSADk3IZt89F1yW6MRuCnlxZsRFotUnm0F','2019-04-03 05:07:12','2019-04-03 05:07:12'),(8,'hoi','hoi@gmai.da','àd','8090808',7898,NULL,'2019-04-03 05:26:34','2019-04-03 05:26:34'),(9,'Hoang Huu Hoi','hoi@gamil.com','unknown','0987654321',2222,'jjqsfJna7EPm49aYYHYuZk7mgOqY5Ydojq7IRn8lipdD5l8KKAphx5XdZasn','2019-04-04 04:57:45','2019-04-04 04:57:45'),(10,'Hoi 2','hoi@mgial.com','unknown','0987654321',2222,'iS0Yvhf3WwQ16ximw1qvJ0LQ04qYxFczpzDcX1UgY0X94MAZR6mNPj3lrImQ','2019-04-04 05:02:56','2019-04-04 05:02:56'),(11,'Hoi 123','hoiaa@adad.adad','unknown','0987654321',2222,'NdbCUq4J9aF9MnWQCN9rf9HI6iB25cUlbQZYVaYUZ86BIeHKNcUl89iP8cvr','2019-04-04 05:03:38','2019-04-04 05:03:38'),(12,'Hoi111','ho@asd.xn--d-tfa','unknown','0987654321',2222,'P9Ofvn0OEoOFyYmGL2AjsWgXiM98UtkU2bpX2KUAEyUBknfSpPTE0hoi3JcN','2019-04-04 05:07:51','2019-04-04 05:07:51');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-04 19:58:28
